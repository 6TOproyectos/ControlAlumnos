'use strict'

const Curso = require('./course.model');

exports.test = (req,res)=>{
    res.send({message:'Test function is running', user: req.user});
}



exports.register = async(req,res)=>{
    try {
        let data = req.body;
        let curso = new Curso(data);
        await curso.save();
        return res.send({message:'Curso created successfully'})
    } catch (err) {
        console.error(err);
        return res.send({message: 'Error creating Curso',Error: err.message})
    }
}

exports.update = async(req,res)=>{
    try {
        let courseId = req.params.id;
        let data = req.body;
        let courseUpdated = await Curso.findOneAndUpdate({_id: courseId},data,{new:true});
        if(!courseUpdated) return res.status(404).send({message: 'Curso not found and not updated'});
        return res.send({message: 'Curso updated', userUpdated})
    } catch (error) {
        console.error(err);
        return res.status(500).send({message: 'Error updating course'})
    }
}

exports.delete = async(req,res)=>{
    try {
        let courseId = req.params.id;
        let courseDeleted = await Curso.findOne({_id: courseId})
        if(!courseDeleted) return res.send({message: 'Curso not found and not deleted'});
        courseDeleted.remove();
        return res.send({message: `Curso deleted sucessfully`});
    } catch (error) {
        console.error(error);
        return res.status(500).send({message: 'Error not deleted'});

    }
}

exports.getCourses = async(req,res)=>{
    try {
            let courses = await Curso.find();
            return res.send({user});
    } catch (error) {
        console.error(error);
        return res.status(500).send({message: 'Error getting Cursos'});
    }
}