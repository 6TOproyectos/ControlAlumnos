'use strict'

const courseController = require('./course.controller');
const express = require('express');
const api = express.Router();
const { ensureAuth, isAdmin } = require('../services/authenticated')


api.get('/test', courseController.test);
api.post('/register',[ensureAuth, isAdmin], courseController.register);
api.put('/update/:id',[ensureAuth, isAdmin], courseController.update);
api.delete('/delete',[ensureAuth, isAdmin], courseController.delete);
api.get('/get', courseController.getCourses);

module.exports = api;