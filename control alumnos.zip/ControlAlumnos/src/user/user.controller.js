'use strict'


const User = require('./user.model');
const jwt = require('jsonwebtoken');
const { encrypt, checkPassword, validateData } = require('../utils/validate');
const { createToken } = require('../services/jwt');

exports.test = (req,res)=>{
    res.send({message:'Test function is running', user: req.user});
}

exports.register = async(req,res) =>{
    try {
        let data = req.body;
        data.password = await encrypt(data.password);
        if(!data.role) data.role='STUDENT';
        if(data.role !== 'STUDENT'){
            return res.status(403).send({message: 'This rol is not allowed'})
        }
        if(data.title) return res.status(403).send({message:'You cannot add a tittle to a student'});
        if(!data.card || !data.grade) return res.send({message: 'Add all the params'});
        let user = new User(data);
        await user.save();
        return res.send({message: 'Account created successfully'});
    } catch (error) {
        console.error(error);
        return res.status(500).send({message: 'Error creating account',Error: error.message});
    }
}



exports.login = async(req, res)=>{
    try {
        let data = req.body;
        let credentials = { email: data.email, password: data.password};
        let msg = validateData(credentials);
        if(msg) return res.status(400).send({msg});
        let user = await User.findOne({email: data.email});
        if(user && await checkPassword(data.password, user.password)){
            let token = await createToken(user);
            
            return res.send({message: 'User logged successfully', token});
        } 
        
        return res.status(404).send({message: 'Invalid credentials'});
    } catch (error) {
        console.error(error);
        return res.status(500).send({message: 'Error not logged'});
    }
}



exports.update = async(req, res)=>{
    try{
        let userId = req.params.id;
        let data = req.body;
        if(userId != req.user.sub) return res.status(401).send({message: 'Dont have permission to do this action'});
        if(data.password || Object.entries(data).length === 0 || data.role || data.card) return res.status(400).send({message: 'Have submitted some data that cannot be updated'});
        let userUpdated = await User.findOneAndUpdate(
            {_id: req.user.sub},
            data,
            {new: true} 
        )
        if(!userUpdated) return res.status(404).send({message: 'User not found adn not updated'});
        return res.send({message: 'User updated', userUpdated})
    }catch(err){
        console.error(err);
        return res.status(500).send({message: 'Error not updated', err: `Username ${err.keyValue.username} is already taken`});
    }
}

exports.delete = async(req, res)=>{
    try{
        let userId = req.params.id;
        if( userId != req.user.sub) return res.status(401).send({message: 'Dont have permission to do this action'});
        let userDeleted = await User.findOneAndDelete({_id: req.user.sub});
        if(!userDeleted) return res.send({message: 'Account not found and not deleted'});
        return res.send({message: `Account with username ${userDeleted.username} deleted sucessfully`});
    }catch(err){
        console.error(err);
        return res.status(500).send({message: 'Error not deleted'});
    }
}



