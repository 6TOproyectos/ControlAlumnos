'use strict'

const mongoose = require('mongoose');

const userSchema = mongoose.Schema({
    name:{
        type: String,
        required: true
    },
    surname:{
        type: String,
        required: true
    },
    email:{
        type: String,
        required: true,
        unique: true,
    },
    password:{
        type: String,
        required: true
    },
    title:{
        type: String,
    },
    card:{
        type: String
    },
    grade:{
        type: String
    },
    
    role:{
        type: String,
        required: true,
        uppercase: true
    },
    curso1:{
        type: mongoose.Schema.Types.ObjectId, ref: 'Course'
    },
    curso2:{
        type: mongoose.Schema.Types.ObjectId, ref: 'Course'
    },
    curso3:{
        type: mongoose.Schema.Types.ObjectId, ref: 'Course'
    },

});

module.exports = mongoose.model('User',userSchema);